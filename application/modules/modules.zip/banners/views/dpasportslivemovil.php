<a href="<?php echo base_url('copa-america') ?>"> <img class="img-responsive" src="<?php echo base_url('imagenes/febanners/mobilecopaamerica.png') ?>"></a>

<!--dpasportslive-->
<!--<div id="dpasportslivemovil" >
    <div id="dpasportsliveovermovil"></div>
    <iframe id='dpasportsliveframe' frameborder="0" width="100%" height="140px" marginheight="0" marginwidth="0" frameborder="no"
            scrolling="no"
            src="http://sportslive-feed.com.s3.amazonaws.com/futbolecuador/html/indexSAScoreboard.html"></iframe>
</div>
--><!--dpasportslivepopup-->
<!--<div class="contenedordpa">
</div>
-->