<!-- FE_NEW_LATERAL_1 -->
<div id='div-gpt-ad-1413414586192-0' style='width:300px; height:250px;'>
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1413414586192-0'); });
    </script>
</div>