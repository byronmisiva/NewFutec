<!-- /1022247/FE_BRAND_SMART_MIDDLE COPA AMERICA-->
<div id='div-gpt-ad-1432051647687-5' style='height:50px;' class="respiframe" >
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1432051647687-5'); });
    </script>
</div>