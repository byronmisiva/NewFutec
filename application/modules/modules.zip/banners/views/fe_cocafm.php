<div style="width: 240px; margin:auto;" class="hidden-xs hidden-sm">
    <script type="text/javascript" src="https://www.imusicaradios.com.br/go_ccfm/ccfm_embed.min.js" onload="CocaColaEmbed('ec','true',3,undefined,'Futbolecuador')"></script>
    <iframe id="ccfmPlayer" style="width: 240px; height: 90px;"></iframe>
</div>

