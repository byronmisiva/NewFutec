<div class="col-md-3 column margen0">
    <?php echo $FE_Halfbanner;?>
</div>
<div class="col-md-9 column   text-right">
    <?php echo $FE_Superbanner; ?>
</div>