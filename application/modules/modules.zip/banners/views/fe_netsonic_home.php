<div id="netsonic">
</div>
<script type='text/javascript'>
    var cuerpoRef = document.getElementsByTagName("body")[0].innerHTML;
    $(document).ready(function () {
        if (typeof secondskin != 'undefined') {
            console.log (secondskin);
            if (secondskin == 2) {
                $("#netsonic").remove();
                $("#eyeDiv").remove();
                $("#ebDimmer").remove();
            } else {

                //document.write('<script src="http://bs.serving-sys.com/BurstingPipe/adServer.bs?cn=rsb&c=28&pli=14265700&PluID=0&w=1&h=1&ord=[random]&ucm=true"><\/script>');
                //document.write(cuerpoRef);

                //console.log ("publi");
                var container = document.getElementById("netsonic");
                container.innerHTML =  '<a href="http://bs.serving-sys.com/BurstingPipe/adServer.bs?cn=brd&FlightID=14265700&Page=&PluID=0&Pos=2101911275"'+
                    'target="_blank"><img src="http://bs.serving-sys.com/BurstingPipe/adServer.bs?cn=bsr&FlightID=14265700&Page=&PluID=0&Pos=2101911275"' +
                    'border=0 width=1 height=1><\/a>';
            }
        } else {
            $("#netsonic").remove();
            $("#eyeDiv").remove();
            $("#ebDimmer").remove();
        }
    })
</script>
