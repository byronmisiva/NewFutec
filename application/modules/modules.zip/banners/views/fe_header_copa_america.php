<!-- /1022247/FE_BRAND_SMART_HEADER COPA AMERICA-->
<!--<div id='div-gpt-ad-1432051647687-4' style='height:80px;' class="respiframe azulmovistar" >
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1432051647687-4'); });
    </script>
</div>-->

<!-- FE_HEADER -->
<div id='div-gpt-ad-1383593619381-0' class="respiframe azulmovistar" >
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1383593619381-0'); });
    </script>
</div>