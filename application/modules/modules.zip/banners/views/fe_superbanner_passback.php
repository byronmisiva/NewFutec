<!-- Beginning PassBack for Ad unit www.futbolecuador.com/inicio ### size: [[728,90]] -->
<script type='text/javascript' src='http://www.googletagservices.com/tag/js/gpt.js'></script>
<script>
    googletag.pubads().definePassback('8746/www.futbolecuador.com/inicio', [[728,90]]).setTargeting('pos',['top']).display();
</script>
<!-- End Passback -->
 