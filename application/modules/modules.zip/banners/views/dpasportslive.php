<div id="dpasportslive" class="banner300x250 hidden-xs">
<!--    <div id="dpasportsliveover"></div>-->
    <iframe id='dpasportsliveframe' frameborder="0" width="100%" height="90px" marginheight="0" marginwidth="0" frameborder="no"
            scrolling="no"
            src="http://www.misiva.com.ec/banners/copa_america/marcador_en_vivo/"></iframe>
</div>
<!--dpasportslivepopup-->
<!--<div class="flotante hidden-xscc">
    <div id="closeBannerdpa">
        <img src="<?php echo base_url('assets/img/close_banner.png') ?>" width="81"
             height="20">
    </div>
    <div class="contenedor">

    </div>
</div>-->