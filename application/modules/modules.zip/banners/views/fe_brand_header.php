<!-- /1022247/FE_BRAND_HEADER -->
<div id='div-gpt-ad-1432051647687-0' style='height:50px; width:980px;' class="hidden-xs hidden-sm">
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1432051647687-0'); });
    </script>
</div>