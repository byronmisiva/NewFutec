<!-- /1022247/FE_BRAND_SMART_TOPcopa america-->
<div id='div-gpt-ad-1432051647687-6' style='height:50px; width:100%;' class="respiframe" >
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1432051647687-6'); });
    </script>
</div>