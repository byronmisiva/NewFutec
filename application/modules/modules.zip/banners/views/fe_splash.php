<div id="darkLayer" style="display: none"></div>
<div id="FE_LOADING" style="display: none;  z-index: 99999;">
    <!-- FE_LOADING -->
    <div id='div-gpt-ad-1425424774921-0' style='width:800px; height:600px;margin: 0 auto'>
        <div class='closeBanner' onclick='cleanBlackLayer();'>
            <img src='<?= base_url() ?>assets/img/close_banner.png'
                 width='81' height='20'/>
        </div>
        <script type='text/javascript'>
            googletag.cmd.push(function() { googletag.display('div-gpt-ad-1425424774921-0'); });
        </script>
    </div>

</div>