<!-- banner se muestra sobre todo copa america-->
<div id="darkLayer" style="display:none;"  ></div>

<div id="FE_LOADING" style="display:none;"  >
    <!-- FE_LOADING_MOVIL -->
    <div id='div-gpt-ad-1383593884981-1' style='width:320px;height:auto;margin: 0 auto'>
        <div class='closeBanner'>
            <img style="height: 100%;" src='<?=base_url()?>imagenes/public/close_banner.png' />
        </div>
        <script type='text/javascript'>
            googletag.display('div-gpt-ad-1383593884981-1');
        </script>
    </div>
</div>


