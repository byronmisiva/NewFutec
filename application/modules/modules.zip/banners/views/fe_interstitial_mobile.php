<!-- e-planning v4 - Comienzo espacio Futbolecuador.com _ Home _ Interstitial Mobile -->
<script type="text/javascript" language="Javascript1.1">var oIF = true;</script>
<script type="text/javascript" language="Javascript1.1" src="http://ak1.img.e-planning.net/layers/epl-41.js"></script>
<script type="text/javascript" language="Javascript1.1">
    <!--
    var eplArgs = { sV:"http://ak1.img.e-planning.net/",vV:"4",sI:"14f0d",kVs:{  }};
    var eplAdsArray=new Array();
    function eplInit() {
        if (this.readyState == 'complete') {
        document.epl.eplInit(eplArgs);
        for (var i=0; i<eplAdsArray.length; i++) {
        if (eplAdsArray[i][1].custF) document.epl.setCustomAdShow(eplAdsArray[i][0],eplAdsArray[i][1].custF);
        document.epl.setSpace(eplAdsArray[i][0], eplAdsArray[i][1]);
        }
        }
        }
    if (document.epl != undefined) {
        document.epl.eplInit(eplArgs);
        } else {
        var array = document.getElementsByTagName('script');
        var e = undefined;
        for (var i=0; i<array.length; i++) {
        if (array[i].src.indexOf('epl-41.js') != -1) {
        e = array[i];
        }
        }
        if (e != undefined) { e.onreadystatechange = eplInit; }
        }
    function eplAD4(eID,opts) {
        document.write('<div id="eplAdDiv'+ eID +'"></div>');
        if (!opts) opts = {t:2};
        if (document.epl != undefined) {
        if (opts.custF) document.epl.setCustomAdShow(eID,opts.custF);
        document.epl.setSpace(eID, opts);
        } else {
        eplAdsArray.push(new Array(eID, opts));
        }
        }
    //--></script>
<script>eplAD4("7fdf4725216f4d94",{t:1,timeout:0,ma:1,custF:null,wh:"320x480",sd:"14f0d!!http://ads.e-planning.net/!ev!"});</script>
<!-- e-planning v4 - Fin espacio Futbolecuador.com _ Home _ Interstitial Mobile -->