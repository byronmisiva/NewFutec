<!-- /1022247/FE_SKIN -->
<div id='div-gpt-ad-1434137569309-0' class="hidden-xs hidden-sm"
     style='position: fixed; _position: absolute; top: 154px; left: 50%; width: 1050px; height: 600px; margin-left: -695px;'>
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1434137569309-0'); });
    </script>
</div>