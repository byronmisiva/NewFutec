<!-- FE_NEW_HALF -->
<div id='div-gpt-ad-1422631305437-0' style='width:260px; height:90px;' class="hidden-xs hidden-sm">
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1422631305437-0'); });
    </script>
</div>


