<!-- /1022247/FE_BRAND_SKY2 Copa america -->
<div id='div-gpt-ad-1432051647687-2' style='width:728px; height:90px;'class="hidden-xs  ">
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1432051647687-2'); });
    </script>
</div>