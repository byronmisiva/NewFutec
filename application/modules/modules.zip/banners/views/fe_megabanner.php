<div id='FE_NEW_HYPERBANNER' style='width:980px; height:50px;' class="hidden-xs hidden-sm ">
    <!-- FE_NEW_HYPERBANNER -->
    <script type='text/javascript'>GA_googleFillSlot("FE_NEW_HYPERBANNER");</script>
</div>


<script type="text/javascript">
    function see_fold2(estado) {
        if (estado == 'on') {
            //agrandamos a 200 el banner
            $('#FE_NEW_HYPERBANNER').css("height", "200px");
        } else {
            //disminuimos a 50
            $('#FE_NEW_HYPERBANNER').css("height", "50px");
        }
    }
</script>