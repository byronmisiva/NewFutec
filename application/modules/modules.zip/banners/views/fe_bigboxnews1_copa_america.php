<!-- /1022247/FE_HP_BRAND copa america-->
<div id='div-gpt-ad-1432051647687-7' class="banner300x250 hidden-xs" >
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1432051647687-7'); });
    </script>
</div>

<!-- /1022247/FE_BRAND_SMART_MIDDLE  COPA AMERICA-->
<div id='div-gpt-ad-1432051647687-5' class="visible-xs-block respiframe" >
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1432051647687-5'); });
    </script>
</div>