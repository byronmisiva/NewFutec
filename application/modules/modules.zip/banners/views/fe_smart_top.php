<!-- FE_SMART_TOP -->
<div id='div-gpt-ad-1383593619381-4' class="respiframe">
    <script type='text/javascript'>
        googletag.cmd.push(function () {
            googletag.display('div-gpt-ad-1383593619381-4');
        });
    </script>
</div>

<div  class="desplegable-alertas col-md-12 col-xs-12 col-sm-12  margen0">
    <div  class="desplegable-alertas-conten  ">

        <div class=" margen0 despimglogo">
            <img class="img-responsive"
                 src="<?php echo base_url(); ?>imagenes/febanners/images_desplegable_alertas/icono.png">
        </div>
        <div class="   margen0 despimglogo2">
            <a target="_blank" href="https://itunes.apple.com/app/id1008177383"
               onclick="ga('send', 'event', 'btn-ios','click','push');"><img class="img-responsive"
                                                                             src="<?php echo base_url(); ?>imagenes/febanners/images_desplegable_alertas/icono_1.png"></a>
        </div>
        <div class="   margen0 despimglogo2">
            <a target="_blank"
               href="https://play.google.com/store/apps/details?id=com.misiva.futbolecuadorpush"
               onclick="ga('send', 'event', 'btn-android','click','push');"><img class="img-responsive"
                                                                                 src="<?php echo base_url(); ?>imagenes/febanners/images_desplegable_alertas/icono_2.png"></a>
        </div>

    </div>
</div>

<style>
    .despimglogo {
        width: 44px;
        float: left;
        margin-top: 10px;
    }
    .despimglogo2 {
        width: 100px;
        float: left;
    }
    .desplegable-alertas {
        display: none;
        background-image: url("<?php echo base_url();?>imagenes/febanners/images_desplegable_alertas/fondo2.jpg");
        width: 100%;
        height: 89px;
        background-size: auto 138px;
        background-position-y: -49px;
    }

    .desplegable-alertas-conten{
        width: 244px;
        margin: 15px auto 0 ;
    }
</style>

<script type="text/javascript">
    function see_fold() {
        $(".desplegable-alertas").toggle( );
    }

</script>
