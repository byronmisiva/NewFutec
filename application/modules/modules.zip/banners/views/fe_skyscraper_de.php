<div class="skyscraper_de" style="position: absolute; top: 160px; left: 50%; width: 1050px; height: 600px; margin-left: 500px;">
    <!-- /1022247/FE_SKYSCRAPER_DE -->
    <div id='div-gpt-ad-1450734059657-0' style='height:600px; width:160px;'>
        <script type='text/javascript'>
            googletag.cmd.push(function() { googletag.display('div-gpt-ad-1450734059657-0'); });
        </script>
    </div>
</div>