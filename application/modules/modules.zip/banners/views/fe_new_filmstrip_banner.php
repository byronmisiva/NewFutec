<!-- /1022247/FE_NEW_FILMSTRIP_BANNER -->
<div id='div-gpt-ad-1439997438966-0' style='height:600px; width:300px;'>
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1439997438966-0'); });
    </script>
</div>