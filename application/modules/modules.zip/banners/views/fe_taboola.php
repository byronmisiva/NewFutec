<div class="col-md-12  col-xs-12">
    <div id="taboola-below-article-thumbnails"></div>
    <script type="text/javascript">
        window._taboola = window._taboola || [];
        _taboola.push({
            mode: 'thumbnails-b',
            container: 'taboola-below-article-thumbnails',
            placement: 'Below Article Thumbnails',
            target_type: 'mix'
        });
    </script>
</div>