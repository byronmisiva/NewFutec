<!-- /1022247/Amazon_associates -->
<div id='div-gpt-ad-1445466832316-0' style='height:0px; width:665px;' class="hidden-xs">
    <script type='text/javascript'>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1445466832316-0'); });
    </script>
</div>