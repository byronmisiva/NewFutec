<div class="hidden-xs hidden-sm" id='fondo_brand'
     style='position: fixed; _position: absolute; top: 154px; left: 50%; width: 1050px; height: 800px; margin-left: -900px;'>
    <!-- FE_SMART_SPLASH -->
    <script type='text/javascript'>
        GA_googleFillSlot("FE_SKIN");
    </script>
</div>