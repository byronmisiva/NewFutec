
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->


<script
    src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url('assets/js/jquery.plugin.js') ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.countdown.js') ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.countdown-es.js') ?>"></script>
<script src="<?php echo base_url('/assets/js/bootstrap.min.js') ?>"></script>
<script type="text/javascript"
        src="<?php echo base_url('assets/js/carouFredSel/jquery.carouFredSel-6.2.1-packed.js') ?>"></script>
<!-- optionally include helper plugins -->
<script type="text/javascript"
        src="<?php echo base_url('assets/js/carouFredSel/helper-plugins/jquery.mousewheel.min.js') ?>"></script>
<script type="text/javascript"
        src="<?php echo base_url('assets/js/carouFredSel/helper-plugins/jquery.touchSwipe.min.js') ?>"></script>
<script type="text/javascript"
        src="<?php echo base_url('assets/js/carouFredSel/helper-plugins/jquery.transit.min.js') ?>"></script>
<script type="text/javascript"
        src="<?php echo base_url('assets/js/carouFredSel/helper-plugins/jquery.ba-throttle-debounce.min.js') ?>"></script>
<script type="text/javascript"
        src="<?php echo base_url('/assets/js/colorbox/jquery.colorbox.js') ?>"></script>
<script type="text/javascript"
        src="<?php echo base_url('/assets/js/scrool/animatescroll.js') ?>"></script>
<script type="text/javascript"
        src="<?php echo base_url('/assets/js/brasil2014.js') ?>"></script>


<!-- fire plugin onDocumentReady -->
</body>
</html>
