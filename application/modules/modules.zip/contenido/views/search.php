 <div class="col-md-12 separador10 margen0r">
    <div class="panel-heading backcuadros">
        <h4 class="panel-title">
            Resultados Búsqueda
        </h4>
    </div>
    <div id='mod_femagazine' style='position:relative;width:100%; height:793px;' class="separador10-xs">
        <script>
            (function() {
                var cx = '004910472998778424762:x6dnz67sbok';
                var gcse = document.createElement('script');
                gcse.type = 'text/javascript';
                gcse.async = true;
                gcse.queryParameterName = 'gaga';
                gcse.resultSetSize = 'small';
                gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
                '//www.google.com/cse/cse.js?cx=' + cx;
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(gcse, s);
            })();
        </script>
        <gcse:search sort_by="date"></gcse:search>

    </div>
</div>