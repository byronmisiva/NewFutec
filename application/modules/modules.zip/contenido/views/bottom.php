<div class="row clearfix separador10 separador10bot footer-fe">
    <div class="col-md-6 col-sm-6  col-xs-12 copyright-fe">
        2015 © Todos los derechos reservados.
    </div>

    <div class="col-md-6 col-sm-6 col-xs-12 text-right">
        <div class="col-md-6 col-xs-6 text-left margen0">
            <img src="<?php echo base_url(); ?>assets/img/logo_SMG.png" alt="logoSMG" title="logo SMG" class="img-responsive"/>
        </div>
        <div class="col-md-6  col-xs-6 text-right margen0">

            <a href="http://www.misiva.com.ec" target="_blank" alt="Misiva Web Site" style="padding: 0">
                <img src="<?php echo base_url(); ?>assets/img/logo_misiva.png" alt="logoMisiva" title="Logotipo misiva" class="img-responsive"/>
            </a>
        </div>
    </div>
</div>
