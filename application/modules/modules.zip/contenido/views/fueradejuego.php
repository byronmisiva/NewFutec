<!--Tabla de Posiciones-->
<div class="col-md-12 separador10-xs margen0r">
    <div class="panel-heading backcuadros">
        <h4 class="panel-title">
            Fuera de Juego
        </h4>
    </div>
    <div class="  ">
        <div class="containerfueradejuego galeria24content">
            <div class="liquid-slider" id="main-slider24">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/1a.jpg" alt="Diana Guevara"/>
                       <!-- <div class="socialesFueradeJuego">
                        Nombre
                        twiter
                        facebook
                    </div>-->
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/2a.jpg" alt="Diana Guevara"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/3a.jpg" alt="Diana Guevara"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/4a.jpg" alt="Diana Guevara"/>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/5a.jpg" alt="Diana Guevara"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>

        <div class="containerfueradejuego galeria23content">
            <div class="liquid-slider" id="main-slider23">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/3a.jpg" alt="Karen"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>


        <div class="containerfueradejuego galeria22content">
            <div class="liquid-slider" id="main-slider22">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/3a.jpg" alt="Karen"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>

        <div class="containerfueradejuego galeria21content">
            <div class="liquid-slider" id="main-slider21">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/3a.jpg" alt="Karen"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>

        <div class="containerfueradejuego galeria20content">
            <div class="liquid-slider" id="main-slider20">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/3a.jpg" alt="Karen"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>

        <div class="containerfueradejuego galeria19content">
            <div class="liquid-slider" id="main-slider19">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/3a.jpg" alt="Karen"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria18content">
            <div class="liquid-slider" id="main-slider18">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/3a.jpg" alt="Karen"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>

        <div class="containerfueradejuego galeria17content">
            <div class="liquid-slider" id="main-slider17">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/3a.jpg" alt="Karen"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>

        <div class="containerfueradejuego galeria16content">
            <div class="liquid-slider" id="main-slider16">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/3a.jpg" alt="Karen"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>

        <div class="containerfueradejuego galeria15content">

            <div class="liquid-slider" id="main-slider15">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/3a.jpg" alt="Karen"/>
                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>

                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>

        <div class="containerfueradejuego galeria14content">

            <div class="liquid-slider" id="main-slider14">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/3a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria13content">

            <div class="liquid-slider" id="main-slider13">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/3a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria12content">

            <div class="liquid-slider" id="main-slider12">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/3a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/4a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/5a.jpg" alt="Karen"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria11content">

            <div class="liquid-slider" id="main-slider11">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/1a.jpg" alt="Paulina"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/2a.jpg" alt="Paulina"/></div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/3a.jpg" alt="Paulina"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/4a.jpg" alt="Paulina"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/5a.jpg" alt="Pualina"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria10content">

            <div class="liquid-slider" id="main-slider10">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/1a.jpg" alt="Alisson Hidalgo"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/2a.jpg" alt="Alisson Hidalgo"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/3a.jpg" alt="Alisson Hidalgo"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/4a.jpg" alt="Alisson Hidalgo"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/5a.jpg" alt="Alisson Hidalgo"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria9content">

            <div class="liquid-slider" id="main-slider9">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/1a.jpg" alt="Angeles azules"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/2a.jpg" alt="Angeles azules"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/3a.jpg" alt="Angeles azules"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/4a.jpg" alt="Angeles azules"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/5a.jpg" alt="Angeles azules"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria8content">

            <div class="liquid-slider" id="main-slider8">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/1a.jpg" alt="Michelle López"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/2a.jpg" alt="Michelle López"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/3a.jpg" alt="Michelle López"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/4a.jpg" alt="Michelle López"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/5a.jpg" alt="Michelle López"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria7content">

            <div class="liquid-slider" id="main-slider7">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/3a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/4a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/5a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria6content">

            <div class="liquid-slider" id="main-slider6">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/3a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/4a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/5a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria5content">

            <div class="liquid-slider" id="main-slider5">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/3a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/4a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/5a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria4content">

            <div class="liquid-slider" id="main-slider4">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/3a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/4a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/5a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria3content">

            <div class="liquid-slider" id="main-slider3">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/3a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/4a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/5a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria2content">

            <div class="liquid-slider" id="main-slider2">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/1a.jpg" alt="Marcela Recalde"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/2a.jpg" alt="Marcela Recalde"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/3a.jpg" alt="Marcela Recalde"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/4a.jpg" alt="Marcela Recalde"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/5a.jpg" alt="Marcela Recalde"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria1content">

            <div class="liquid-slider" id="main-slider1">
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/1b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/2b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/3b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/3a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/4b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/4a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><div class="thum-fuera"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/5b.jpg" alt=" "/></div>
                    </h2> <img class="img-responsive lazo" data-original="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/5a.jpg" alt="Diana Bastidas"/>

                    <div class="contenidoexclusivo" style="display: none">  </div>
                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>


        <!-- End Container -->

        <div class="col-md-12 text-right fondoazul  ">
            Más hinchas
        </div>


        <div class="linksFueraJuego col-md-12">
            <div class="controlfueraJuego"><img class="prev"
                                                src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/controls/left-fuera.jpg"
                                                width="18" heigth="115"/></div>
            <div class="otrasmodelos">
                <ul>
                    <li class="galeria24"><img id="galeria24" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria24/1b.jpg"
                                               width="110" heigth="140" alt="Diana Guevara"/></li>
                    <li class="galeria23"><img id="galeria23"
                                               src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria23/1b.jpg"
                                               width="110" heigth="140" alt="Ana Milena Cardoso"/></li>
                    <li class="galeria22"><img id="galeria22" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria22/1b.jpg"
                                               width="110" heigth="140" alt="Carolina"/></li>
                    <li class="galeria21"><img id="galeria21" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria21/1b.jpg"
                                               width="110" heigth="140" alt="Carolina"/></li>
                    <li class="galeria20"><img id="galeria20" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria20/1b.jpg"
                                               width="110" heigth="140" alt="Carolina"/></li>
                    <li class="galeria19"><img id="galeria19" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria19/1b.jpg"
                                               width="110" heigth="140" alt="Alison"/></li>
                    <li class="galeria18"><img id="galeria18" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria18/1b.jpg"
                                               width="110" heigth="140" alt="Alison"/></li>
                    <li class="galeria17"><img id="galeria17" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria17/1b.jpg"
                                               width="110" heigth="140" alt="Alison"/></li>
                    <li class="galeria16"><img id="galeria16" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/1b.jpg"
                                               width="110" heigth="140" alt="Alison"/></li>
                    <li class="galeria15"><img id="galeria15" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/1b.jpg"
                                               width="110" heigth="140" alt="Alison"/></li>
                    <li class="galeria14"><img id="galeria14" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/1b.jpg"
                                               width="110" heigth="140" alt="Alison"/></li>
                    <li class="galeria13"><img id="galeria13" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/1b.jpg"
                                               width="110" heigth="140" alt="Karen"/></li>
                    <li class="galeria12"><img id="galeria12" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/1b.jpg"
                                               width="110" heigth="140" alt="Karen"/></li>
                    <li class="galeria11"><img id="galeria11" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/1b.jpg"
                                               width="110" heigth="140" alt="Paulina"/></li>
                    <li class="galeria10"><img id="galeria10" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/1b.jpg"
                                               width="110" heigth="140" alt="Alisson Hidalgo"/></li>
                    <li class="galeria9"><img id="galeria9" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/1b.jpg"
                                              width="110" heigth="140" alt="Angeles Azules"/></li>
                    <li class="galeria8"><img id="galeria8" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/1b.jpg"
                                              width="110" heigth="140" alt="Michelle López"/></li>
                    <li class="galeria7"><img id="galeria7" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/1b.jpg"
                                              width="110" heigth="140" alt="Adriana Palacios"/></li>
                    <li class="galeria6"><img id="galeria6" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/1b.jpg"
                                              width="110" heigth="140" alt="Sanny Cabrera"/></li>
                    <li class="galeria5"><img id="galeria5" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/1b.jpg"
                                              width="110" heigth="140" alt="Francesca Galarza"/></li>
                    <li class="galeria4"><img id="galeria4" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/1b.jpg"
                                              width="110" heigth="140" alt=""/></li>
                    <li class="galeria3"><img id="galeria3" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/1b.jpg"
                                              width="110" heigth="140" alt="Andrea Ortiz"/></li>
                    <li class="galeria2"><img id="galeria2" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/1b.jpg"
                                              width="110" heigth="140" alt="Marcela Recalde"/></li>
                    <li class="galeria1"><img id="galeria1" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/1b.jpg"
                                              width="110" heigth="140" alt="Diana Bastidas"/></li>
                </ul>
            </div>
            <div class="controlfueraJuego">
                <img class="next"
                     src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/controls/right-fuera.jpg"
                     width="18" heigth="115"/>
            </div>
            <!-- Feel free to load scripts in the footer -->
            <link rel="stylesheet" href="<?= base_url('assets/css/fueradejuego/liquid-slider.css') ?>"/>
            <link type="text/css" rel="stylesheet" href="<?= base_url('assets/css/fueradejuego/fueradejuego.css') ?>"/>
        </div>
    </div>
</div>