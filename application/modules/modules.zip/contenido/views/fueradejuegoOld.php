<!--Tabla de Posiciones-->
<div class="col-md-12 separador10-xs margen0r">
    <div class="panel-heading backcuadros">
        <h4 class="panel-title">
            Fuera de Juego
        </h4>
    </div>
    <div class="  ">
        <div class="containerfueradejuego galeria16content">
            <div class="liquid-slider" id="main-slider16">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/3a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/4a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/5a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria15content">

            <div class="liquid-slider" id="main-slider15">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/3a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/4a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/5a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria14content">

            <div class="liquid-slider" id="main-slider14">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/3a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/4a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/5a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria13content">

            <div class="liquid-slider" id="main-slider13">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/3a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/4a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/5a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria12content">

            <div class="liquid-slider" id="main-slider12">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/1a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/2a.jpg" alt="Karen"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/3a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/4a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/5a.jpg" alt="Karen"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria11content">

            <div class="liquid-slider" id="main-slider11">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/1a.jpg" alt="Paulina"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/2a.jpg" alt="Paulina"/></div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/3a.jpg" alt="Paulina"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/4a.jpg" alt="Paulina"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/5a.jpg" alt="Pualina"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria10content">

            <div class="liquid-slider" id="main-slider10">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/1a.jpg" alt="Alisson Hidalgo"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/2a.jpg" alt="Alisson Hidalgo"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/3a.jpg" alt="Alisson Hidalgo"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/4a.jpg" alt="Alisson Hidalgo"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/5a.jpg" alt="Alisson Hidalgo"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria9content">

            <div class="liquid-slider" id="main-slider9">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/1a.jpg" alt="Angeles azules"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/2a.jpg" alt="Angeles azules"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/3a.jpg" alt="Angeles azules"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/4a.jpg" alt="Angeles azules"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/5a.jpg" alt="Angeles azules"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria8content">

            <div class="liquid-slider" id="main-slider8">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/1a.jpg" alt="Michelle López"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/2a.jpg" alt="Michelle López"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/3a.jpg" alt="Michelle López"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/4a.jpg" alt="Michelle López"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/5a.jpg" alt="Michelle López"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria7content">

            <div class="liquid-slider" id="main-slider7">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/3a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/4a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/5a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria6content">

            <div class="liquid-slider" id="main-slider6">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/3a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/4a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/5a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria5content">

            <div class="liquid-slider" id="main-slider5">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/3a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/4a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/5a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria4content">

            <div class="liquid-slider" id="main-slider4">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/3a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/4a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/5a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria3content">

            <div class="liquid-slider" id="main-slider3">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/3a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/4a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/5a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria2content">

            <div class="liquid-slider" id="main-slider2">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/1a.jpg" alt="Marcela Recalde"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/2a.jpg" alt="Marcela Recalde"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/3a.jpg" alt="Marcela Recalde"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/4a.jpg" alt="Marcela Recalde"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/5a.jpg" alt="Marcela Recalde"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <div class="containerfueradejuego galeria1content">

            <div class="liquid-slider" id="main-slider1">
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/1b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/1a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/2b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/2a.jpg" alt="Diana Bastidas"/>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/3b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/3a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/4b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/4a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>
                <div><h2 class="title hidden"><img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/5b.jpg" alt=" "/>
                    </h2> <img class="img-responsive" src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/5a.jpg" alt="Diana Bastidas"/>

                    <div class="logosGPAS">
                        <div class="logoGP"><a href="http://goo.gl/jhlPq" target="_blank">
                                <div></div>
                            </a></div>
                        <div class="logoAS"><a href="http://goo.gl/76UWV" target="_blank">
                                <div></div>
                            </a></div>
                    </div>
                </div>

            </div>

        </div>
        <!-- End Container -->

        <div class="col-md-12 text-right fondoazul  ">
            Más hinchas
        </div>


        <div class="linksFueraJuego col-md-12">
            <div class="controlfueraJuego"><img class="prev"
                                                src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/controls/left-fuera.jpg"
                                                width="18" heigth="163"/></div>
            <div class="otrasmodelos">
                <ul>
                    <li class="galeria16"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria16/1a.jpg"
                                               width="110" heigth="140" alt="Alison"/></li>
                    <li class="galeria15"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria15/1a.jpg"
                                               width="110" heigth="140" alt="Alison"/></li>
                    <li class="galeria14"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria14/1a.jpg"
                                               width="110" heigth="140" alt="Alison"/></li>
                    <li class="galeria13"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria13/1a.jpg"
                                               width="110" heigth="140" alt="Karen"/></li>
                    <li class="galeria12"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria12/1a.jpg"
                                               width="110" heigth="140" alt="Karen"/></li>
                    <li class="galeria11"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria11/1a.jpg"
                                               width="110" heigth="140" alt="Paulina"/></li>
                    <li class="galeria10"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria10/1a.jpg"
                                               width="110" heigth="140" alt="Alisson Hidalgo"/></li>
                    <li class="galeria9"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria9/1a.jpg"
                                              width="110" heigth="140" alt="Angeles Azules"/></li>
                    <li class="galeria8"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria8/1a.jpg"
                                              width="110" heigth="140" alt="Michelle López"/></li>
                    <li class="galeria7"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria7/1a.jpg"
                                              width="110" heigth="140" alt="Adriana Palacios"/></li>
                    <li class="galeria6"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria6/1a.jpg"
                                              width="110" heigth="140" alt="Sanny Cabrera"/></li>
                    <li class="galeria5"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria5/1a.jpg"
                                              width="110" heigth="140" alt="Francesca Galarza"/></li>
                    <li class="galeria4"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria4/1a.jpg"
                                              width="110" heigth="140" alt=""/></li>
                    <li class="galeria3"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria3/1a.jpg"
                                              width="110" heigth="140" alt="Andrea Ortiz"/></li>
                    <li class="galeria2"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria2/1a.jpg"
                                              width="110" heigth="140" alt="Marcela Recalde"/></li>
                    <li class="galeria1"><img src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/galeria1/1a.jpg"
                                              width="110" heigth="140" alt="Diana Bastidas"/></li>
                </ul>
            </div>
            <div class="controlfueraJuego">
                <img class="next"
                     src="<?= base_url() ?>imagenes/galerias-fuera-de-juego/controls/right-fuera.jpg"
                     width="18" heigth="163"/>
            </div>

            <!-- Feel free to load scripts in the footer -->
            <link rel="stylesheet" href="<?= base_url('assets/css/fueradejuego/liquid-slider.css?refresh=' . rand(1, 2000)  ) ?>"/>

            <link type="text/css" rel="stylesheet" href="<?= base_url('assets/css/fueradejuego/fueradejuego.css?refresh=' . rand(1, 2000)  ) ?>"/>

        </div>
    </div>
</div>