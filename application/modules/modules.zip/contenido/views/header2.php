<div class="col-md-8 col-sm-8 margen0">
    <?php echo $rotativas; ?>
</div>
<div class="col-md-4 col-sm-4 hidden-xs">
    <div class="col-md-12 margen0r">
        <?php echo $marcadorvivo; ?>
    </div>
    <div class="col-md-12 col-sm-12 separador10 ">
        <?php echo $FE_Bigboxbanner; ?>
    </div>
</div>



