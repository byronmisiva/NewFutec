<!--Sorteo Juventus-->
<div class="col-md-12 separador10-xs margen0r" xmlns="http://www.w3.org/1999/html">
    <div class="panel-heading backcuadros">
        <h4 class="panel-title">
            Sorteo Camiseta Juventus
        </h4>
    </div>

    <div class=" margen0 col-md-12">
        <img class="img-responsive" src="http://www.futbolecuador.com/imagenes/concursos/camiseta-juventus-adidas-2.jpg"
             alt="Juventus 1"/>

        <!--<img class="img-responsive" src="http://www.futbolecuador.com/imagenes/concursos/camiseta-juventus-adidas-1.jpg"
             alt="Juventus 2"/>-->
    </div>

    <!-- End Container -->



    <div class=" col-md-12">
        <iframe src="https://www.misiva.com.ec/formulario-camiseta-fe/" width="100%" height="500px"frameborder="0" scrolling="no">

        </iframe>
    </div>
    <div class="col-md-12 text-right fondoazul  ">
        <a href="http://www.futbolecuador.com/imagenes/concursos/reglamento-de-terminos-y-condiciones-para-el-concurso-camiseta-2015-la-juventaus.pdf" target="_blank">Términos y condiciones</a>
    </div>


</div>
