<!--ficha Equipo-->
<div class="col-md-12 separador10-xs margen0">
    <div class="panel-heading backcuadros">
        <h1 class="tabla"><?php echo $infoEquipo->name; ?></h1>
    </div>
</div>
