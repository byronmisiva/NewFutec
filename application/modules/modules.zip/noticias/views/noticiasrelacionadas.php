
<?php
foreach ($noticias as $noticia) {
    ?>
        <div style="margin-left: 10px"><?php echo $noticia ?></div>
    <?php
}
?>
